<h3><?php echo $_LANG['ADD_NEW_CUSTOM_PAGE']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form action="add_custompage.php?action=new_page" method="post">
  <table style="text-align: center;" class="table table-bordered">
    <tbody>
      <tr>
        <td><?php echo $_LANG['PAGE_TITLE']; ?></td>
        <td><input type="text" name="page_title" /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="page_content"
          ></textarea></td>
      </tr>
    </tbody>
  </table>
  <br />
  <center>
    <button type="submit" class="btn btn-info"><?php echo $_LANG['ADD_NEW_CUSTOM_PAGE']; ?></button>
  </center>
</form>
<?php } ?>
