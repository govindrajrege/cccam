<h3><?php echo $_LANG['MONITOR']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(!empty($pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV) AND isset($REKvHOFbCSDKSEtanOrwCXWaPeLxBQZXvmDToU) AND !empty( $REKvHOFbCSDKSEtanOrwCXWaPeLxBQZXvmDToU ) ) { ?>
<p align="center"><?php echo $_LANG['MONITOR_DESC']; ?></p>
<a
  href="monitor.php?action=resetall&master_server_id=<?php echo $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc; ?>"
><font size="4" color="red">[<?php echo $_LANG['RESET_ALL']; ?>]</font></a>
</td>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['LINE_USERNAME']; ?></th>
      <th scope="col"><?php echo $_LANG['LATEST_ZAPS']; ?></th>
      <th scope="col"><?php echo $_LANG['TOTAL_WARNINGS']; ?></th>
      <th scope="col"><?php echo $_LANG['INFO']; ?></th>
      <th scope="col"><?php echo $_LANG['RESET']; ?></th>
      <th scope="col"><?php echo $_LANG['MODIFY']; ?></th>
      <th scope="col"><?php echo $_LANG['SEND_EMAIL']; ?></th>
    </tr>
  </thead>
  <tbody> <?php $HVvRvJUqNbIrswknYijhsHPbAPjctFJYdHGto = intval(mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_LAST_MIN_ZAPS']); foreach($REKvHOFbCSDKSEtanOrwCXWaPeLxBQZXvmDToU as $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM) { $MVxFYLxJdIYdlSkGEvSOgWdgcXnEjIbgOM = ZUrSdeXnmuZXglBYlzpmZSNdazohydQtlQ( $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['line_id'] ); $KpDoVntEjpDoFvhsjjbKsOPLkmpQzuMk = count(unserialize($rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['warnings'])); $ttXyPPopSZTNEuycKAdAQkUTsWhdQHMdsQcXvA = ""; $kXVQuHSkTVckDostgYyqhjQJoPOtaRUleQ = $_LANG['MONITOR_EMAIL_NO_BAN']; if($MVxFYLxJdIYdlSkGEvSOgWdgcXnEjIbgOM['blocked'] == 1) { $ttXyPPopSZTNEuycKAdAQkUTsWhdQHMdsQcXvA = "<font color='orange'>[".$_LANG['BLOCKED']."]</font> "; $kXVQuHSkTVckDostgYyqhjQJoPOtaRUleQ = $_LANG['MONITOR_EMAIL_BAN']; } ?> <tr> <?php if($KpDoVntEjpDoFvhsjjbKsOPLkmpQzuMk > 0) { echo "<td><font size='3' color='red'>" . $ttXyPPopSZTNEuycKAdAQkUTsWhdQHMdsQcXvA . $MVxFYLxJdIYdlSkGEvSOgWdgcXnEjIbgOM['username'] . "</font></td>"; echo "<td><font size='3' color='orange'>".$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['latest_zaps']." / ".$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['diff']."</font></td>"; echo "<td><font size='3' color='red'>".$KpDoVntEjpDoFvhsjjbKsOPLkmpQzuMk."</font></td>"; echo "<td><a onclick=\"ajax_request_dialog('monitor.php?action=show_warnings&line_id={$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['line_id']}')\" class=\"table-icon info\" href=\"#\"></a></td>"; } else { echo "<td><font color='green'>" . $ttXyPPopSZTNEuycKAdAQkUTsWhdQHMdsQcXvA . $MVxFYLxJdIYdlSkGEvSOgWdgcXnEjIbgOM['username'] . "</font></td>"; echo "<td><font color='green'>".$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['latest_zaps']." / ".$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['diff']."</font></td>"; echo "<td><font color='green'>".$KpDoVntEjpDoFvhsjjbKsOPLkmpQzuMk."</font></td>"; echo "<td>-</td>"; } ?> <td><a
        href="monitor.php?action=reset&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['line_id']; ?>&master_server_id=<?php echo $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc; ?>"
        class="table-icon reset" title="<?php echo $_LANG['RESET']; ?>"
      ></a></td>
      <td><a
        href="monitor.php?action=unblock&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['line_id']; ?>&master_server_id=<?php echo $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc; ?>"
        class="table-icon unblock"
        title="<?php echo $_LANG['UNBLOCK']; ?>"
      > <a
          href="monitor.php?action=block&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['line_id']; ?>&master_server_id=<?php echo $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc; ?>"
          class="table-icon block"
          title="<?php echo $_LANG['BLOCK']; ?>"
        ></a></a></td>
      <td><a
        onclick="return confirm('<?php echo $kXVQuHSkTVckDostgYyqhjQJoPOtaRUleQ; ?>')"
        href="monitor.php?action=sendemail&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['line_id']; ?>&master_server_id=<?php echo $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc; ?>"
        class="table-icon email"
        title="<?php echo $_LANG['SEND_EMAIL']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
<?php } ?> <?php } ?>
