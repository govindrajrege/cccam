<h3><?php echo $_LANG['SETTINGS_TITLE']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form action="settings.php?action=save" method="post">
  <table class="table table-bordered">
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['SERVER_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SERVER_NAME']; ?></b></td>
        <td><input type="text" name="SERVER_NAME" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SERVER_NAME'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_FULL_URL']; ?></b></td>
        <td><input type="text" name="FULL_URL" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['FULL_URL'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_LOGO_URL']; ?></b></td>
        <td><input type="text" name="LOGO_URL" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['LOGO_URL'];?>"
        /></td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['PAYMENTS_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_ACCEPT_PAYMENTS']; ?></b></td>
        <td><input type="radio" name="ACCEPT_PAYMENTS" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ACCEPT_PAYMENTS'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ACCEPT_PAYMENTS" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ACCEPT_PAYMENTS'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYMENT_METHODS']; ?></b></td>
        <td><select name="PAYMENT_METHODS[]" multiple="multiple">
            <option value="paypal"
              <?php if(mcLib::PhBQosZlwKZusPeDModuwGmPXqTlnAXQ('paypal')) echo 'selected'; ?>
            >Paypal</option>
            <option value="paysafe"
              <?php if(mcLib::PhBQosZlwKZusPeDModuwGmPXqTlnAXQ('paysafe')) echo 'selected'; ?>
            >PaySafeCard</option>
            <option value="ukash"
              <?php if(mcLib::PhBQosZlwKZusPeDModuwGmPXqTlnAXQ('ukash')) echo 'selected'; ?>
            >Ukash</option>
            <option value="custom"
              <?php if(mcLib::PhBQosZlwKZusPeDModuwGmPXqTlnAXQ('custom')) echo 'selected'; ?>
            >Custom Payments</option>
        </select></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CURRENCY_CODE']; ?></b></td>
        <td><input type="text" name="CURRENCY_CODE" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CURRENCY_CODE'];?>"
        /></td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['CUSTOM_PAYMENT_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CUSTOM_PAYMENT_TID']; ?></b></td>
        <td><input type="radio" name="REQUIRE_TID" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['REQUIRE_TID'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="REQUIRE_TID" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['REQUIRE_TID'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CUSTOM_PAYMENT_TP']; ?></b></td>
        <td><input type="radio" name="REQUIRE_TP" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['REQUIRE_TP'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="REQUIRE_TP" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['REQUIRE_TP'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['PAYPAL_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_EMAIL']; ?></b></td>
        <td><input type="text" name="PAYPAL_EMAIL" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_EMAIL'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_CMD']; ?></b></td>
        <td><input type="radio" name="PAYPAL_CMD" value="_donations"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_CMD'] == '_donations') echo 'checked'; ?>
        /> Donations <input type="radio" name="PAYPAL_CMD"
          value="_xclick"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_CMD'] == '_xclick') echo 'checked'; ?>
        /> Buy Now</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_ITEM_NAME']; ?></b></td>
        <td><input type="text" name="PAYPAL_ITEM_NAME" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_ITEM_NAME'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_ORDER_ID']; ?></b></td>
        <td><input type="radio" name="PAYPAL_ORDER_ID" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_ORDER_ID'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="PAYPAL_ORDER_ID" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_ORDER_ID'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_INVOICE']; ?></b></td>
        <td><input type="radio" name="PAYPAL_INVOICE" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_INVOICE'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="PAYPAL_INVOICE" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_INVOICE'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><hr /></td>
        <td><hr /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_ENABLE_PAYPAL_SHIELD']; ?> (<a
            target="_blank" href="shield.php"
          ><font color='red'>See here</font></a>)</td>
        <td><input type="radio" name="ENABLE_PAYPAL_SHIELD" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_PAYPAL_SHIELD'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ENABLE_PAYPAL_SHIELD" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_PAYPAL_SHIELD'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_SHIELD']; ?></b></td>
        <td><input type="text" name="PAYPAL_SHIELD" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_SHIELD'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_THANK_YOU']; ?></b></td>
        <td><input type="text" name="PAYPAL_THANKYOU" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_THANKYOU'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYPAL_HEADER_IMAGE']; ?></b></td>
        <td><input type="text" name="PAYPAL_HEADER_IMG" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['PAYPAL_HEADER_IMG'];?>"
        /></td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['CAPTCHA_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CAPTCHA_LOGIN']; ?></b></td>
        <td><input type="radio" name="CAPTCHA_LOGIN" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAPTCHA_LOGIN'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="CAPTCHA_LOGIN" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAPTCHA_LOGIN'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CAPTCHA_REGISTER']; ?></b></td>
        <td><input type="radio" name="CAPTCHA_REGISTER" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAPTCHA_REGISTER'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="CAPTCHA_REGISTER" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAPTCHA_REGISTER'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CAPTCHA_FORGOT']; ?></b></td>
        <td><input type="radio" name="CAPTCHA_FORGOT" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAPTCHA_FORGOT'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="CAPTCHA_FORGOT" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAPTCHA_FORGOT'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['MONITOR_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_MINIMUM_ZAP_VALUE']; ?></b></td>
        <td><input type="text" name="MONITOR_LAST_MIN_ZAPS"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_LAST_MIN_ZAPS']; ?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_MON_AUTO_BLOCK']; ?></b></td>
        <td><input type="radio" name="MONITOR_AUTO_BLOCK" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_AUTO_BLOCK'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="MONITOR_AUTO_BLOCK" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_AUTO_BLOCK'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_BLOCK_LINE_AFTER']; ?></b></td>
        <td><input type="text" name="MONITOR_BLOCK_WARNINGS"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_BLOCK_WARNINGS']; ?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_BLOCK_LINE_EMAIL']; ?></b></td>
        <td><input type="radio" name="MONITOR_BLOCK_INFORM" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_BLOCK_INFORM'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="MONITOR_BLOCK_INFORM" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MONITOR_BLOCK_INFORM'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['REGISTRATION_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_ALLOW_REGISTRATION']; ?></b></td>
        <td><input type="radio" name="ALLOW_REGISTRATIONS" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ALLOW_REGISTRATIONS'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ALLOW_REGISTRATIONS" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ALLOW_REGISTRATIONS'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_ALLOW_SECOND_ACCOUNT']; ?></b></td>
        <td><input type="radio" name="ALLOW_SECOND_ACCOUNT" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ALLOW_SECOND_ACCOUNT'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ALLOW_SECOND_ACCOUNT" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ALLOW_SECOND_ACCOUNT'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_VERIFY']; ?></b></td>
        <td><input type="radio" name="CONFIRMATION_EMAIL" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CONFIRMATION_EMAIL'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="CONFIRMATION_EMAIL" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CONFIRMATION_EMAIL'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_USERNAME_ALPHA']; ?></b></td>
        <td><input type="radio" name="USERNAME_ALPHA" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['USERNAME_ALPHA'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="USERNAME_ALPHA" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['USERNAME_ALPHA'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_USERNAME_STRLEN']; ?></b></td>
        <td><input type="text" name="USERNAME_STRLEN"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['USERNAME_STRLEN'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_MIN_PASS']; ?></b></td>
        <td><input type="text" name="MIN_PASSWORD" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MIN_PASSWORD'];?>"
        /></td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['TESTLINE_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_TEST_LINE_ENABLE']; ?></b></td>
        <td><input type="radio" name="TEST_LINE_ENABLE" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['TEST_LINE_ENABLE'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="TEST_LINE_ENABLE" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['TEST_LINE_ENABLE'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_TEST_LINE_DAYS']; ?></b></td>
        <td><select name="TESTLINES_DATES[]" size="7"
          multiple="multiple"
        >
            <option value="Monday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Monday')) echo 'selected'; ?>
            >Monday</option>
            <option value="Tuesday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Tuesday')) echo 'selected'; ?>
            >Tuesday</option>
            <option value="Wednesday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Wednesday')) echo 'selected'; ?>
            >Wednesday</option>
            <option value="Thursday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Thursday')) echo 'selected'; ?>
            >Thursday</option>
            <option value="Friday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Friday')) echo 'selected'; ?>
            >Friday</option>
            <option value="Saturday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Saturday')) echo 'selected'; ?>
            >Saturday</option>
            <option value="Sunday"
              <?php if(mcLib::ZGHRtBfgqJVGdOhBSLFUNeaBBWgQUVoJA('Sunday')) echo 'selected'; ?>
            >Sunday</option>
        </select></td>

    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['LINE_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_CAN_DELETE_LINES']; ?></b></td>
        <td><input type="radio" name="CAN_DELETE_LINES" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAN_DELETE_LINES'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="CAN_DELETE_LINES" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAN_DELETE_LINES'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_LINE_DELETE_IN']; ?></b></td>
        <td><input type="text" name="DELETE_LINES_IN" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['DELETE_LINES_IN'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_REMOVE_LINECOST_PERCENT']; ?></b></td>
        <td><input type="text" name="REMOVE_LINECOST_PERCENT" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['REMOVE_LINECOST_PERCENT'];?>"
        /></td>
      </tr>
      <tr>
        <td><hr /></td>
        <td><hr /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['INFORM_USER_SETTING']; ?></b></td>
        <td><input type="text" name="EXPIRELINE_INFORM_USER_HOURS"
          size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EXPIRELINE_INFORM_USER_HOURS'];?>"
        /></td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['OTHER_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_ENABLE_TICKETS']; ?></b></td>
        <td><input type="radio" name="ENABLE_TICKETS" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_TICKETS'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ENABLE_TICKETS" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_TICKETS'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_PAYMENT_HISTORY']; ?></b></td>
        <td><input type="radio" name="CAN_PAYMENT_HISTORY" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAN_PAYMENT_HISTORY'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="CAN_PAYMENT_HISTORY" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CAN_PAYMENT_HISTORY'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['MAIL_SETTINGS']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_MAIL_FROM']; ?></b></td>
        <td><input type="text" name="MAIL_FROM" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['MAIL_FROM'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_USE_SERVER_SMTP']; ?></b></td>
        <td><input type="radio" name="SERVER_SMTP" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SERVER_SMTP'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="SERVER_SMTP" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SERVER_SMTP'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>


    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['EXTERNAL_EMAIL']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SMTP_HOST']; ?></b></td>
        <td><input type="text" name="SMTP_HOST" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_HOST'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SMTP_PORT']; ?></b></td>
        <td><input type="text" name="SMTP_PORT" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_PORT'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SMTP_ENCRYPTION']; ?></b></td>
        <td><input type="radio" name="SMTP_ENCRYPTION" value="ssl"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_ENCRYPTION'] == 'ssl') echo 'checked'; ?>
        /> SSL <input type="radio" name="SMTP_ENCRYPTION" value="tls"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_ENCRYPTION'] == 'tls') echo 'checked'; ?>
        /> TLS <input type="radio" name="SMTP_ENCRYPTION" value="no"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_ENCRYPTION'] == 'no') echo 'checked'; ?>
        /> No Encryption</td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SMTP_USERNAME']; ?></b></td>
        <td><input type="text" name="SMTP_USERNAME" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_USERNAME'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SMTP_PASSWORD']; ?></b></td>
        <td><input type="password" name="SMTP_PASSWORD" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_PASSWORD'];?>"
        /></td>
      </tr>
      <tr>
        <td><b><?php echo $_LANG['SETTING_SMTP_FROM_NAME']; ?></b></td>
        <td><input type="text" name="SMTP_FROM_NAME" size="30"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['SMTP_FROM_NAME'];?>"
        /></td>
      </tr>
    </tbody>
    <thead>
      <tr>
        <th colspan="2"><?php echo $_LANG['COPYRIGHTS_REMOVAL']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><b><?php echo $_LANG['SETTING_WRITE_COPYRIGHTS']; ?></b></td>
        <td>
        <input type="hidden" name="REMOVE_COPYRIGHTS" value="1" />
        <input type="text" name="OWN_COPYRIGHTS" size="50"
          value="<?php echo htmlentities(mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['OWN_COPYRIGHTS']);?>"
        />
      </tr>
    </thead>
  </table>
  <br />
  <br />
  <center>
    <button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button>
  </center>
</form>
<?php } ?>
