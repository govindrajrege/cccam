<div class="row">
  <div class="col-sm-3">
    <div class="tile-stats tile-red">
      <div class="icon">
        <i class="entypo-users"></i>
      </div>
      <div class="num" data-start="0"
        data-end="<?php echo $lxSkLuiByzLiZNhwhMenXckXodkSoLFeRVkyY; ?>"
        data-postfix="" data-duration="1500" data-delay="0"
      >0</div>
      <h3><?php echo $_LANG['TOTAL_REGISTERED_USERS']; ?></h3>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="tile-stats tile-green">
      <div class="icon">
        <i class="entypo-chart-bar"></i>
      </div>
      <div class="num" data-start="0"
        data-end="<?php echo $XljAiuvsmGfuVVXcPHsVdjPQtHgtZWBqBZioJ; ?>"
        data-postfix="" data-duration="1500" data-delay="600"
      >0</div>
      <h3><?php echo $_LANG['TOTAL_ONLINE']; ?></h3>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="tile-stats tile-aqua">
      <div class="icon">
        <i class="entypo-flash"></i>
      </div>
      <div class="num" data-start="0"
        data-end="<?php echo $XjCywyJxPCGxGEIWkegOMPDUgEtUduAzaakjCcYGM; ?>"
        data-postfix="" data-duration="1500" data-delay="1200"
      >0</div>
      <h3><?php echo $_LANG['TOTAL_ACTIVE_LINES']; ?></h3>
    </div>
  </div>
  <div class="col-sm-3">
    <div class="tile-stats tile-blue">
      <div class="icon">
        <i class="glyphicon glyphicon-usd"></i>
      </div>
      <div class="num" data-start="0"
        data-end="<?php echo $NXdKWegxhJCCNLmXFbRBhAwpMDOyZGwzzJtqYA; ?>"
        data-postfix="" data-duration="1500" data-delay="1800"
      >0</div>
      <h3><?php echo $_LANG['TOTAL_INCOME']; ?></h3>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"><?php echo $_LANG['SYSTEM_IFNO']; ?></div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body"> <?php if(!empty($lzgiEiUvHINQUNeYhuFZbrjXWpOSOsJbrfZCg)) { ?> <h3>
          <font color="red">CPU Info</font>
        </h3>
        <div class="row">
          <div class="col-md-12"> <?php foreach($lzgiEiUvHINQUNeYhuFZbrjXWpOSOsJbrfZCg['cores'] as $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg) { ?> <h5><?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_name'] . ' @ ' . $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['speed'] . 'Mhz'; ?></h5>
            <center>
              [<strong><font color="blue"><?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg["cpu_usage"]; ?>%</font>
                <u>CPU Core Usage</u></strong>]
            </center>
            <div class="progress progress-striped active"> <?php if($xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage'] >= 0 AND $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage'] <= 7) { ?> <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage']; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage']; ?>%">
              </div> <?php } elseif($xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage'] <= 20) { ?> <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="<?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage']; ?>" aria-valuemin="5" aria-valuemax="100" style="width: <?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage']; ?>%">
              </div> <?php } else { ?> <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="<?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage']; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $xDoZeGLKuYRIcyEIuBLvsbWzDzvFjAeTfyFECGzg['cpu_usage']; ?>%">
              </div> <?php } ?> </div> <?php } } else { echo "<div class=\"alert alert-danger\">Can't get cpu info</div>"; } ?> <?php if(!empty($ZjoNZUsvobOLvMcUsdzhoToDxrvpEcZY)) { $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM = $ZjoNZUsvobOLvMcUsdzhoToDxrvpEcZY[0]; $vOfzyYZhOyEpKciacDdtoeLmGnMgnMJGMupXQvS = $ZjoNZUsvobOLvMcUsdzhoToDxrvpEcZY[1]; ?> <h3>
              <font color="red">Memory Usage</font>
            </h3>
            <div class="row">
              <div class="col-md-12">
                <center>
                  <strong><?php echo '['. $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM["used"].'/'.$KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['total']."] MB"; ?></strong>
                </center>
                <div class="progress progress-striped active"> <?php if($KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent'] > 0 AND $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent'] <= 10) { ?> <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="<?php echo $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent']; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent']; ?>%">
                  </div> <?php } elseif($KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent'] <= 30) { ?> <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="<?php echo $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent']; ?>" aria-valuemin="5" aria-valuemax="100" style="width: <?php echo $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent']; ?>%">
                  </div> <?php } else { ?> <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="<?php echo $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent']; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $KsTIZmxbdsjkNOIivplNvQdodqupBtgiNPM['percent']; ?>%">
                  </div> <?php } ?> </div>
              </div>
            </div> <?php } else { echo "<div class=\"alert alert-danger\">Can't get memory info</div>"; } ?> </div>
        </div>
      </div>
    </div>
