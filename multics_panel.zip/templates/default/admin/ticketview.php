<h3><?php echo $_LANG['TICKETS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php $ZlTTrVtMDyRLIVRmCGFqbpotVwgDWZpRck = $mcMember->enuLZXwCAGrbvPofcgEYEOgeRSIcNwSMgoze($MZMulCxQTMOUXUPPXSSutvafAXePsbuHBKU['INFO']['member_id']); echo '<p align="center"><b><font color="orange" size="3">'.$MZMulCxQTMOUXUPPXSSutvafAXePsbuHBKU['INFO']['topic_title'].' by '.$ZlTTrVtMDyRLIVRmCGFqbpotVwgDWZpRck.' @ '.date("F j, Y, g:i a",$MZMulCxQTMOUXUPPXSSutvafAXePsbuHBKU['INFO']['date']).'</font></b></p>'; ?>
<br />
<br />
<table style="text-align: center;" class="table table-bordered">
  <tbody> <?php foreach($MZMulCxQTMOUXUPPXSSutvafAXePsbuHBKU['POSTS'] AS $SezVgOxAZwzTHIKWlWuxhpSFCGJIdczeCds) { if($SezVgOxAZwzTHIKWlWuxhpSFCGJIdczeCds['admin_reply'] == 1) { $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw = '<font color="blue">Administrator</font>'; } else { $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw = $ZlTTrVtMDyRLIVRmCGFqbpotVwgDWZpRck; } echo '<tr>'; echo '<td style="width: 10%;">'; echo '<b><font size="2">'.$DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw .'></font></b>'; echo '</td>'; echo '<td style="width: 80%; text-align: left;">'; echo wordwrap(str_ireplace("<br style=","",$SezVgOxAZwzTHIKWlWuxhpSFCGJIdczeCds['post']),150,"<br />",true); echo '</td>'; echo '<td style="width: 10%;">'; echo "<a onclick=\"return confirm('{$_LANG['DELETE_CONFIRM']}')\" href=\"ticketview.php?action=delete&id={$MZMulCxQTMOUXUPPXSSutvafAXePsbuHBKU['INFO']['id']}&remove_post_id={$SezVgOxAZwzTHIKWlWuxhpSFCGJIdczeCds['id']}'\" class=\"table-icon delete\" title=\"{$_LANG['DELETE']}\"></a>"; echo '</td>'; echo '</tr>'; } ?> </tbody>
</table>
<br />
<br />
<form method="post"
  action="ticketview.php?action=new_post&id=<?php echo $MZMulCxQTMOUXUPPXSSutvafAXePsbuHBKU['INFO']['id']; ?>"
>
  <table style="text-align: center;" class="table table-bordered">
    <thead>
      <th scope="col"><?php echo $_LANG['REPLY']; ?></th>
    </thead>
    <tbody>
      <tr>
        <td> <?php echo $_LANG['TICKET_MESSAGE']; ?><br /> <textarea
            name="post" cols="100" rows="10"
          ></textarea>
        </td>
      </tr>
      <tr>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['REPLY']; ?></button></td>
      </tr>
    </tbody>
  </table>
</form>
<?php } ?>
