<h3><?php echo $_LANG['SESSIONS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['STATUS']; ?></th>
      <th scope="col"><?php echo $_LANG['USERNAME_FIELD']; ?></th>
      <th scope="col"><?php echo $_LANG['USER_AGENT']; ?></th>
      <th scope="col"><?php echo $_LANG['IP']; ?></th>
      <th scope="col"><?php echo $_LANG['EXPIRE_DATE']; ?></th>
      <th scope="col" style="width: 65px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($fSPQcaadVlTgDKgeXnMabiHnVmgQpPiw as $oANUOgfTiWaupZMvWyMjPmKLTBZtQJk) { if($oANUOgfTiWaupZMvWyMjPmKLTBZtQJk['expire_date'] >= time()) { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/online.png' title='Valid Session'>"; } else { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/offline.png' title='Expired Session'>"; } ?> <tr>
      <td><?php echo $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ; ?></td>
      <td><?php echo $oANUOgfTiWaupZMvWyMjPmKLTBZtQJk['username']; ?></td>
      <td><?php echo $oANUOgfTiWaupZMvWyMjPmKLTBZtQJk['user_agent']; ?></td>
      <td><?php echo $oANUOgfTiWaupZMvWyMjPmKLTBZtQJk['ip']; ?></td>
      <td><?php echo date("F j, Y, g:i a",$oANUOgfTiWaupZMvWyMjPmKLTBZtQJk['expire_date']); ?></td>
      <td><a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        class="table-icon delete"
        href="sessions.php?action=del&id=<?php echo $oANUOgfTiWaupZMvWyMjPmKLTBZtQJk['id']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
<br />
<?php } ?>
