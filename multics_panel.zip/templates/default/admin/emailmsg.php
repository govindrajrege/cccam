<h3><?php echo $_LANG['EMAIL_MESSAGES']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form method="post" action="emailmsg.php?action=save">
  <table style="text-align: center;" class="table table-bordered">
    <tbody>
      <tr>
        <th colspan="2"><?php echo $_LANG['VERIFY_EMAIL_COL']; ?></th>
      </tr>
      <tr>
        <td><?php echo $_LANG['EMAIL_TITLE'] ?></td>
        <td><input type="text" name="EMAIL_MSG_VERIFY_SUB" size="100"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_VERIFY_SUB']; ?>"
        /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="EMAIL_MSG_VERIFY"
          ><?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_VERIFY']; ?></textarea></td>
      </tr>
      <tr>
        <th colspan="2"><?php echo $_LANG['FORGOT_EMAIL_COL']; ?></th>
      </tr>
      <tr>
        <td><?php echo $_LANG['EMAIL_TITLE'] ?></td>
        <td><input type="text" name="EMAIL_MSG_FORGOT_SUB" size="100"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_FORGOT_SUB']; ?>"
        /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="EMAIL_MSG_FORGOT"
          ><?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_FORGOT']; ?></textarea></td>
      </tr>
      <tr>
        <th colspan="2"><?php echo $_LANG['EXPIRE_EMAIL_COL']; ?></th>
      </tr>
      <tr>
        <td><?php echo $_LANG['EMAIL_TITLE'] ?></td>
        <td><input type="text" name="EMAIL_MSG_EXPIRE_LINE_SUB"
          size="100"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_EXPIRE_LINE_SUB']; ?>"
        /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="EMAIL_MSG_EXPIRE_LINE"
          ><?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_EXPIRE_LINE']; ?></textarea></td>
      </tr>
      <tr>
        <th colspan="2"><?php echo $_LANG['MONITOR_BAN_EMAIL_COL']; ?></th>
      </tr>
      <tr>
        <td><?php echo $_LANG['EMAIL_TITLE'] ?></td>
        <td><input type="text" name="EMAIL_MSG_MONITOR_BAN_SUB"
          size="100"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_MONITOR_BAN_SUB']; ?>"
        /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="EMAIL_MSG_MONITOR_BAN"
          ><?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_MONITOR_BAN']; ?></textarea></td>
      </tr>
      <tr>
        <th colspan="2"><?php echo $_LANG['MONITOR_WARN_EMAIL_COL']; ?></th>
      </tr>
      <tr>
        <td><?php echo $_LANG['EMAIL_TITLE'] ?></td>
        <td><input type="text" name="EMAIL_MSG_MONITOR_WARN_SUB"
          size="100"
          value="<?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_MONITOR_WARN_SUB']; ?>"
        /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="EMAIL_MSG_MONITOR_WARN"
          ><?php echo mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['EMAIL_MSG_MONITOR_WARN']; ?></textarea></td>
      </tr>
    </tbody>
  </table>
  <br />
  <center>
    <button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button>
  </center>
</form>
<?php } ?>
</div>
