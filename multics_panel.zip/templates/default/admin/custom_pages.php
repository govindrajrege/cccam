<h3><?php echo $_LANG['LIST_CUSTOM_PAGES']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(empty($RQounhGtAGHAQMdIQWKiJQacUorTaqlFU)) { echo "<p align='center'><font color='red'>".$_LANG['NO_CUSTOMPAGES_FOUND']."</font></p><br /><br />"; } else { ?>
<form method="post" action="custom_pages.php?action=change_order">
  <table style="text-align: center;"
    class="table table-bordered datatable" id="table-1"
  >
    <thead>
      <tr>
        <th scope="col"><?php echo $_LANG['PAGE_TITLE']; ?></th>
        <th scope="col"><?php echo $_LANG['ORDER']; ?></th>
        <th scope="col"><?php echo $_LANG['MODIFY']; ?></th>
      </tr>
    </thead>
    <tbody> <?php foreach($RQounhGtAGHAQMdIQWKiJQacUorTaqlFU as $IvURkNAMHctbGGyWqOdbvVRDtJvfOawsXMQc) { ?> <tr>
        <td><?php echo $IvURkNAMHctbGGyWqOdbvVRDtJvfOawsXMQc['page_title']; ?></td>
        <td><input type="text" size="2"
          name="order[<?php echo $IvURkNAMHctbGGyWqOdbvVRDtJvfOawsXMQc['id']; ?>]"
          value="<?php echo $IvURkNAMHctbGGyWqOdbvVRDtJvfOawsXMQc['order'] ?>"
        /></td>
        <td><a
          href="custom_pages_view.php?id=<?php echo $IvURkNAMHctbGGyWqOdbvVRDtJvfOawsXMQc['id']; ?>"
          class="table-icon edit" title="<?php echo $_LANG['EDIT']; ?>"
        ></a> <a
          onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
          href="custom_pages.php?action=delete&id=<?php echo $IvURkNAMHctbGGyWqOdbvVRDtJvfOawsXMQc['id']; ?>"
          class="table-icon delete"
          title="<?php echo $_LANG['DELETE']; ?>"
        ></a></td> <?php } ?> 
    
    </tbody>
  </table> <?php if(!empty($RQounhGtAGHAQMdIQWKiJQacUorTaqlFU)) { echo "<center><button type=\"submit\" class=\"btn btn-info\">{$_LANG['SAVE']}</button></center>"; } ?> </form>
<?php } ?> <?php } ?>
