<h3><?php echo $_LANG['LANGUAGE']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form method="post"
  action="language_view.php?action=save&id=<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['id']; ?>"
>
  <table style="text-align: center;" class="table table-bordered">
    <thead>
      <tr>
        <th scope="col"><?php echo $_LANG['LANG_TITLE_KEY']; ?></th>
        <th scope="col"><?php echo $_LANG['LANG_TITLE_VALUE']; ?></th>
      </tr>
    </thead>
    <tbody> <?php foreach($_LANGFILE as $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc=>$snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM) { ?> <tr>
        <td><?php echo $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc; ?></td>
        <td><input type="text"
          value="<?php echo $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM; ?>"
          size="75"
          name="<?php echo $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc; ?>"
        /></td>
      </tr> <?php } ?> </tbody>
  </table>
  <center>
    <button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button>
  </center>
</form>
<?php } ?>
