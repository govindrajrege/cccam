<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['EDIT_GROUP']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post"
          action="edit_group.php?action=save&id=<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['id']; ?>"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['GROUP_NAME']; ?></label>
            <div class="col-sm-2">
              <input type="text" class="form-control" name="group_name"
                value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['group_name']; ?>"
              />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['GROUP_COLOR']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control colorpicker"
                  name="group_color" data-format="hex"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['group_color']; ?>"
                />
                <div class="input-group-addon">
                  <i class="color-preview"></i>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['CAN_ACCESS_ADMINCP']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="is_admin"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['is_admin'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['GROUP_IS_BANNED']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="is_banned"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['is_banned'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['TOTAL_TESTLINES']; ?></label>
            <div class="col-sm-2">
              <input type="text" class="form-control"
                value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['total_testlines']; ?>"
                name="total_testlines"
              />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PERCENT_DISCOUNT']; ?></label>
            <div class="col-sm-2">
              <input type="text" class="form-control"
                name="percent_discount"
                value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['percent_discount']; ?>"
              />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['EDIT_GROUP']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?> 
