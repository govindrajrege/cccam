<h3><?php echo $_LANG['DATABASE_MANAGE']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<center>
  <form action="database.php?action=download" method="post">
    <table style="text-align: center;" class="table table-bordered">
      <thead>
        <th colspan="1"><?php echo $_LANG['TAKE_BACKUP']; ?></th>
      </thead>
      <tbody>
        <tr>
          <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
        </tr>
      </tbody>
    </table>
  </form>
  <form enctype="multipart/form-data"
    action="database.php?action=restore" method="post"
  >
    <table style="text-align: center;" class="table table-bordered">
      <thead>
        <th colspan="2"><?php echo $_LANG['RESTORE_DB']; ?></th>
      </thead>
      <tbody>
        <tr>
          <td><?php echo $_LANG['SELECT_FILE']; ?></td>
          <td><input type="file" name="db" /></td>
        </tr>
        <tr>
          <td></td>
          <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
        </tr>
      </tbody>
    </table>
  </form>
</center>
<?php } ?>
