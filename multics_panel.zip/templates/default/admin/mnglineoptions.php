<h3><?php echo $_LANG['LINE_PACKAGES']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(!empty($ftIznUWGlGdmUWNSGAwhoEtPjjUAiUIs)) { ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['MASTER_SERVER']; ?></th>
      <th scope="col"><?php echo $_LANG['LINE_PACKAGE_NAME']; ?></th>
      <th scope="col"><?php echo $_LANG['LINE_PACKAGE_DURATION']; ?></th>
      <th scope="col"><?php echo $_LANG['LINE_PACKAGE_TYPE']; ?></th>
      <th scope="col"><?php echo $_LANG['LINE_PACKAGE_NPRICE']; ?></th>
      <th scope="col" style="width: 65px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($ftIznUWGlGdmUWNSGAwhoEtPjjUAiUIs as $MModueQXIxnweTxcEUFBrOXDQdRZHcdE) { $DCbBNajoIqloBeLmdmGWCWkBNsTgUSFFE = VgqYebRrABaUsFBfKbqNMjyrxiWPEXIXKE($MModueQXIxnweTxcEUFBrOXDQdRZHcdE['server_id']); $iStRIBnCMmcChbePwiBEQwOgKGfeHpNuQYCE = KFZdtFwjjtJNXOLayulYRyUacBdBTixXiK($MModueQXIxnweTxcEUFBrOXDQdRZHcdE['duration_in']); ?> <tr>
      <td><?php echo $DCbBNajoIqloBeLmdmGWCWkBNsTgUSFFE['domain']; ?></td>
      <td><?php echo $MModueQXIxnweTxcEUFBrOXDQdRZHcdE['option_name']; ?></td>
      <td><?php echo $MModueQXIxnweTxcEUFBrOXDQdRZHcdE['duration']." {$iStRIBnCMmcChbePwiBEQwOgKGfeHpNuQYCE['full']}"; ?></td>
      <td><?php echo ($MModueQXIxnweTxcEUFBrOXDQdRZHcdE['option_type'] == 0) ? $_LANG['LINE_PACKAGE_TEST'] : $_LANG['LINE_PACKAGE_OFFICIAL']; ?></td>
      <td><?php echo ($MModueQXIxnweTxcEUFBrOXDQdRZHcdE['normal_price'] == 0) ? "<font color='red'>{$_LANG['FREE']}</font>" : "<font color='blue'>{$MModueQXIxnweTxcEUFBrOXDQdRZHcdE['normal_price']}" . " " . mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CURRENCY_CODE']."</font>"; ?></td>
      <td><a
        href="edit_package.php?id=<?php echo $MModueQXIxnweTxcEUFBrOXDQdRZHcdE['id']; ?>"
        class="table-icon edit" title="<?php echo $_LANG['EDIT']; ?>"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        class="table-icon delete"
        href="mnglineoptions.php?action=del_option&id=<?php echo $MModueQXIxnweTxcEUFBrOXDQdRZHcdE['id']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
<br />
<?php } ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['LINE_PACKAGE_ADD']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post" action="mnglineoptions.php?action=new_option"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['SELECT_MULTICS_SERVER']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="master_server_id"
                onchange="location.href='mnglineoptions.php?master_server_id=' + this.value"
              >
                <option value="">----</option> <?php foreach($TOalrzJJdXiIDajyLzxIJgHvcBliArw as $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw) { if($FsxhAYpfMnsoJJOndPwBLEjbQdoAbIyTCbQ AND $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id'] == $WJmMUXTlDnCQvIzBRxSNHjZvZCoBIAWIeXNKEU) { echo "<option value=\"{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}\" selected>{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</option>"; } else { echo "<option value=\"{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}\">{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</option>"; } } ?> </select>
            </div>
          </div> <?php if(!empty($FsxhAYpfMnsoJJOndPwBLEjbQdoAbIyTCbQ)) { ?> <div
            class="form-group"
          >
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_TYPE']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="option_type"> <?php echo "<option value=\"0\">{$_LANG['LINE_PACKAGE_TEST']}</option>"; echo "<option value=\"1\">{$_LANG['LINE_PACKAGE_OFFICIAL']}</option>"; ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_NAME']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="option_name"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['SUBSERVER_SELECT_PACKAGE']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="server_id"> <?php foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$WJmMUXTlDnCQvIzBRxSNHjZvZCoBIAWIeXNKEU] as $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu) { echo "<option value=\"{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']}\">{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['emulator_name']} - {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['description']} [{$_LANG['PORT']}: {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['port']}]</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PROFILES']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="profiles[]" size="10"
                multiple="multiple"
              > <?php foreach($PUWXehduSmEptZYeeotezsmpWnQXCRgpVRPsE as $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI) { echo "<option value=\"{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']}\">{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['profile_name']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PACKAGE_MONITOR_EXCLUDE']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="monitor_exclude">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PACKAGE_CHANGE_EMU']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="allow_ch_emu" checked>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PACKAGE_SELECT_GROUPS']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="groups[]" size="5"
                multiple="multiple"
              > <?php foreach($oHBSDAuHJygtOaTtglLlZLpFieculMarhTWExQ as $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk) { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\">{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_DURATION']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="duration" />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_DURATION_IN']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="duration_in">
                <option value="h"><?php echo $_LANG['LINE_PACKAGE_DUR_HOURS']; ?></option>
                <option value="d"><?php echo $_LANG['LINE_PACKAGE_DUR_DAYS']; ?></option>
                <option value="m"><?php echo $_LANG['LINE_PACKAGE_DUR_MONTHS']; ?></option>
                <option value="y"><?php echo $_LANG['LINE_PACKAGE_DUR_YEARS']; ?></option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_NPRICE'] . ' - ' . mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CURRENCY_CODE']; ?> (<font
              color="red"
            ><?php echo $_LANG['ENTER0FREE']; ?></font>)</label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="normal_price"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['NOTES']; ?></label>
            <div class="col-sm-5">
              <textarea class="form-control" id="field-ta" name="info"></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['LINE_PACKAGE_ADD']; ?></button>
            </div>
          </div> <?php } ?> </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
