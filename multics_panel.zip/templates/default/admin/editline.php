<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['EDIT_LINE']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post"
          action="editline.php?action=save&id=<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['id']; ?>"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_USERNAME']; ?></label>
            <div class="col-sm-3">
              <div class="input-group">
                <input type="text" class="form-control" name="username"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['username']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PASSWORD']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="password"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['password']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_OWNER']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="owner">
                <option
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['member_id']; ?>"
                  selected
                ><?php echo $mcMember->enuLZXwCAGrbvPofcgEYEOgeRSIcNwSMgoze($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['member_id']); ?></option> <?php foreach($JHurzFuNvXZKpptMwRRmyetfKPuAoDlLrGxk as $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM) { if($rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id'] == $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['member_id']) continue; echo "<option value=\"{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']}\">{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['username']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['SUBSERVER_SELECT']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="server_id">
                <option
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['server_id']; ?>"
                  selected
                ><?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['emulator_name'] . "- {$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['description']} [{$_LANG['PORT']}: {$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['port']}]"; ?></option> <?php foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$UHmGOZBjqNuPIJelIDsOiqyGbXyHQSVhcBwVuk['id']] as $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu) { if($UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id'] == $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['server_id']) continue; echo "<option value=\"{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']}\">{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['emulator_name']} - {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['description']} [{$_LANG['PORT']}: {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['port']}]</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['RESHARE_LEVEL']; ?> [<font
              color="red"
            ><?php echo $_LANG['ONLY_CCCAM']; ?></font>]</label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="reshare"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['reshare']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PROFILES']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="profile_ids[]"
                size="10" multiple="multiple"
              > <?php $BbNgLHAyaBpzhRMcrNUpyYcBIebLGuTTUZLqOAyM = explode(",",$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['profiles']); foreach($PUWXehduSmEptZYeeotezsmpWnQXCRgpVRPsE as $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI) { if(in_array($WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id'],$BbNgLHAyaBpzhRMcrNUpyYcBIebLGuTTUZLqOAyM)) echo "<option value=\"{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']}\" selected>{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['profile_name']}</option>"; else echo "<option value=\"{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']}\">{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['profile_name']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['NOTES']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="notes"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['notes']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['UNLIMITED_LINE']; ?></label>
            <div class="col-sm-2">
              <div class="make-switch">
                <input type="checkbox" name="unlimited"
                  <?php if(is_null($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['date_end'])) echo 'checked'; ?>
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['EXPIRE_DATE']; ?></label>
            <div class="col-sm-3">
              <div class="date-and-time">
                <input type="text" class="form-control datepicker"
                  name="date_end" data-format="mm/dd/yyyy"
                  value="<?php if(!is_null($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['date_end'])) echo date("m/d/Y",$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['date_end']); ?>"
                > <input type="text" class="form-control timepicker"
                  name="date_end_hour" data-template="dropdown"
                  data-default-time="11:25 AM" data-show-meridian="true"
                  value="<?php if(!is_null($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['date_end'])) echo date("g:i a",$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['date_end']); ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_IS_TEST']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="test_line"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['test_line'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['MONITOR_EXCLUDE']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="monitor_exclude"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['monitor_exclude'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['CHANGE_EMU_ALLOW']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="allow_ch_emu"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['allow_ch_emu'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['SELECT_NUMBER_LINES']; ?></label>
            <div class="col-sm-5">
              <select name="numDep" id="dropdown1">
                <option value="">---</option> <?php for($PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII=1;$PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII<=20;$PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII++) { echo "<option value=\"$PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII\">$PkmhXPbPvCcSikBmDzjHuyljGIDgckcLrskII</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-8"> <?php foreach($ftIznUWGlGdmUWNSGAwhoEtPjjUAiUIs as $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc=>$snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM) { echo $_LANG['LINE_OPTION_KEY'].': <input type="text" name="line_option_keys[]" value="'.$uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc.'" />&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp; '.$_LANG['LINE_OPTION_VALUE'].': <input type="text" size="40" name="line_option_values[]" value="'.$snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM.'" /><br /><br />'; } ?> <div
                id="textboxDiv"
              ></div>
              <br />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['EDIT_LINE']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
<script type="text/javascript"> $(document).ready(function() { $("#dropdown1").change(function() { var selVal = $(this).val(); $("#textboxDiv").html(''); if(selVal > 0) { for(var i = 1; i<= selVal; i++) { $("#textboxDiv").append('<?php echo $_LANG['LINE_OPTION_KEY']; ?>: <input type="text" name="line_option_keys[]" value="" />&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp;<?php echo $_LANG['LINE_OPTION_VALUE']; ?>: <input type="text" size="40" name="line_option_values[]" value="" /><br /><br />'); } } }); }); </script>
