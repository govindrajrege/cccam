<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['EDIT_USER']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post"
          action="edituser.php?id=<?php echo $pXDrlwVXwuxAzlpShefsNcSIaDMBjP; ?>&action=save"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['USERNAME_FIELD']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="username"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['username']; ?>"
                  disabled
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PASSWORD_FIELD']; ?> (<font
              color="red"
            ><?php echo $_LANG['PASSWORD_CHANGE_ADMIN']; ?></font>)</label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="password" />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['EMAIL_FIELD']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="email"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['email']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['AC_BALANCE']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="balance"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['balance']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['USER_VERIFY']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="verified"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['verified'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['USER_GROUP']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="group_id"> <?php foreach($oHBSDAuHJygtOaTtglLlZLpFieculMarhTWExQ as $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk) { if($ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id'] == $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['member_group_id']) { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\" selected>{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } else { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\">{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['ABLE_TO_GENERATE_TL']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="ABLE_TO_GENERATE">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['EDIT_USER']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
