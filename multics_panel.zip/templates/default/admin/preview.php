
<div class="full_w">
  <div class="h_title"><?php echo $_LANG['PREVIEW_CONFIG_TITLE']; ?></div> <?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(!empty($pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV)) { ?> <p
    align="center"
  ><?php echo $_LANG['PREVIEW_CONFIG_DESC']; ?></p>
  <center>
    <textarea name="preview_config" cols="115" rows="30" disabled><?php echo $LfMfpOENHloEtVkOXPzMkQHbeTYnfmWVQ; ?></textarea>
  </center> <?php } } ?> </div>
