<h3><?php echo $_LANG['MANAGE_SERVER_NEWS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(empty($zYTplVJnxlIqvnqZoiUQDggLDFKXKijEY)) { echo "<p align='center'><font color='red'>".$_LANG['NO_SERVERNEWS']."</font></p><br /><br />"; } else { ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['NEW_TITLE']; ?></th>
      <th scope="col"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($zYTplVJnxlIqvnqZoiUQDggLDFKXKijEY as $zesREaAOEinCToeHAWYXrNZXAsunxHkpTLJg) { ?> <tr>
      <td><?php echo $zesREaAOEinCToeHAWYXrNZXAsunxHkpTLJg['news_title']; ?></td>
      <td><a
        href="server_news_view.php?id=<?php echo $zesREaAOEinCToeHAWYXrNZXAsunxHkpTLJg['id']; ?>"
        class="table-icon edit" title="<?php echo $_LANG['EDIT']; ?>"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        href="server_news.php?action=delete&id=<?php echo $zesREaAOEinCToeHAWYXrNZXAsunxHkpTLJg['id']; ?>"
        class="table-icon delete"
        title="<?php echo $_LANG['DELETE']; ?>"
      ></a></td> <?php } ?> 
  
  </tbody>
</table>
<?php } ?> <?php } ?>
