<h3><?php echo $_LANG['TOOLS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<table style="text-align: center;" class="table table-bordered">
  <tbody>
    <form action="tools.php?action=delete_expired_lines" method="post">
      <tr>
        <td><?php echo $_LANG['TOOLS_DEL_LINES'];?></td>
        <td><input type="text" name="days" /><br />
        <button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
      </tr>
    </form>
    <form action="tools.php?action=delete_expired_test_lines"
      method="post"
    >
      <tr>
        <td><?php echo $_LANG['TOOL_DEL_EX_TEST'];?></td>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
      </tr>
    </form>
    <form action="tools.php?action=empty_test_lines_date" method="post">
      <tr>
        <td><?php echo $_LANG['TOOL_EMPTY_TESTLINES_DATE'];?></td>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
      </tr>
    </form>
    <form action="tools.php?action=delete_lines_from_server"
      method="post"
    >
      <tr>
        <td><?php echo $_LANG['TOOL_DEL_SERVL'];?> ( <font color="red"><?php echo $_LANG['NO_UNDO']; ?></font>
          )</td>
        <td><select name="server_id"> <?php foreach($LTUlnIWqhHTNQqmsDvWfCHXcTlmyVtfhuuyDppf as $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc => $LTUlnIWqhHTNQqmsDvWfCHXcTlmyVtfhuuyDppf) { foreach($LTUlnIWqhHTNQqmsDvWfCHXcTlmyVtfhuuyDppf as $bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ) { if($bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['port'] == 0) $bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['port'] = '*'; echo "<option value=\"{$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['id']}\">[{$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['domain_name']}] - [{$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['emulator_name']}] - {$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['description']} [{$_LANG['PORT']}: {$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['port']}]</option>"; } } ?> </select>
          <br />
          <button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button>
        </td>
      </tr>
    </form>
    <form action="tools.php?action=get_emails" method="post">
      <tr>
        <td><?php echo $_LANG['TOOL_GET_EMAILS'];?></td>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
      </tr>
    </form>
  </tbody>
</table>
</form>
<?php } ?>
