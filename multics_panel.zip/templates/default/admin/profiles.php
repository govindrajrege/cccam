<h3><?php echo $_LANG['LIST_PROFILES']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(!empty($pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV)) { ?>
<form action="profiles.php?action=save_default" name="submitform"
  method="post"
/>
<input type="hidden" name="submit" value="1" />
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col" style="width: 85px;"><?php echo $_LANG['STATUS']; ?></th>
      <th scope="col"><?php echo $_LANG['PROFILE_NAME']; ?></th>
      <th scope="col" style="width: 65px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($PUWXehduSmEptZYeeotezsmpWnQXCRgpVRPsE as $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI) { ?> <tr>
      <td> <?php if($CJmouEtuOMxIAGgLTpwUDGyzqMGaAEdjSxs[$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']] == 0) { echo "<a href=\"#\" class=\"table-icon warning\" title=\"{$_LANG['NO_PORT']}\"></a>"; } else { echo "<a href=\"#\" class=\"table-icon ok\" title=\"{$_LANG['PROFILE_NORMAL']}\"></a>"; } ?> </td>
      <td>[<?php echo $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['profile_name']; ?>]</td>
      <td><a
        href="editprofile.php?id=<?php echo $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']; ?>"
        class="table-icon edit" title="<?php echo $_LANG['EDIT']; ?>"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        href="profiles.php?action=del_profile&id=<?php echo $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']; ?>"
        class="table-icon delete"
        title="<?php echo $_LANG['DELETE']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
</form>
<?php } } ?> 
