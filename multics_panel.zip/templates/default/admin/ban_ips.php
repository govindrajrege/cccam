<h3><?php echo $_LANG['PLUGIN_BAN_IPS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form method="post" action="ban_ips.php?action=setting">
  <table style="text-align: center;" class="table table-bordered">
    <tbody>
      <tr>
        <td><?php echo $_LANG['SETTING_ENABLE_IP_BAN_LIST']; ?> </td>
        <td><input type="radio" name="ENABLE_IP_BAN_LIST" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_IP_BAN_LIST'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ENABLE_IP_BAN_LIST" value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_IP_BAN_LIST'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td></td>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button></td>
      </tr>
    </tbody>
  </table>
</form>
<form method="post" action="ban_ips.php?action=save">
  <table style="text-align: center;" class="table table-bordered">
    <thead>
      <tr>
        <th scope="col"><?php echo $_LANG['IPS_LIST_MANAGE']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><textarea name="ban_ips" cols="150" rows="30"><?php foreach($HATQwEqjJhhySskxdMXvCyJTrUQnLE as $pvbAQpstHErCNjbiVEyojhtHeHsWsFYnivUxB) echo $pvbAQpstHErCNjbiVEyojhtHeHsWsFYnivUxB['ip'] . "\r\n"; ?></textarea></td>
      </tr>
      <tr>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button></td>
      </tr>
    </tbody>
  </table>
</form>
<?php } ?>
