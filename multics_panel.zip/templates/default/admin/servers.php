<h3><?php echo $_LANG['MANAGE_SUBSERVERS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<center>
  <p align="center"><?php echo $_LANG['EMULATORS_DESC']; ?></p>
  <form method="post" action="servers.php?action=emulators_settings">
    <table style="text-align: center;" class="table table-bordered">
      <thead>
        <tr>
          <th scope="col"><?php echo $_LANG['MASTER_SERVER']; ?></th> <?php foreach($ssyAoHeSjuaVqJNHUoyEMNBPhDQUldyooZIIL as $mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE=>$WbqowJxFazqBlfvnumNpfSSEYZPBSCUMHxyCE) { echo "<th scope=\"col\">{$WbqowJxFazqBlfvnumNpfSSEYZPBSCUMHxyCE['emulator_name']}</th>"; } ?> </tr>
      </thead>
      <tbody> <?php foreach($TOalrzJJdXiIDajyLzxIJgHvcBliArw as $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc=>$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw) { echo "<tr>"; echo "<td>{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</td>"; $khafiiQFEaNpUlqJcFTlZmxPULSLoGqJM = $gsQEYGnyrohmeblsNxIsxEzIZurUbpdbrZqlAA[$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']]; foreach($ssyAoHeSjuaVqJNHUoyEMNBPhDQUldyooZIIL as $mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE => $WbqowJxFazqBlfvnumNpfSSEYZPBSCUMHxyCE) { $HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU = gzYLbuDxOAXvDpzJDcFiNVYxZxnoiRxzjUMrtck($XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id'],$mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE); echo "<td>"; if($khafiiQFEaNpUlqJcFTlZmxPULSLoGqJM[$mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE][0] == 1) { if($HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU === FALSE) { echo "<font color='red'>".$_LANG['NO_DEF_EMU_SERVER']."</font><br />"; } echo $_LANG['EMULATORS_USER_ACCESS']." <input type=\"checkbox\" name=\"user_access[{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}][]\" value=\"{$mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE}\" checked /><br />"; } else { echo $_LANG['EMULATORS_USER_ACCESS']." <input type=\"checkbox\" name=\"user_access[{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}][]\" value=\"{$mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE}\" /><br />"; } echo "<select name=\"default_server_id[{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}][$mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE]\">"; if($HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU !== FALSE) { echo "<option value=\"{$HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU['id']}\" selected>{$WbqowJxFazqBlfvnumNpfSSEYZPBSCUMHxyCE['emulator_name']} - {$HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU['description']} [{$_LANG['PORT']}: {$HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU['port']}]</option>"; } else { echo "<option value=\"0\">{$_LANG['EMULATOR_SELECT_DEFAULT']}</option>"; } foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']] as $bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ) { if($bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['emulator_id'] != $mFjmmTzCSEVaGVsjrvnAunlrqqPgGykE || $bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['id'] == $HMBNxiaYWqkCfSveXojQvpaLQLBWEocFLaEGpU['id']) { continue; } echo "<option value=\"{$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['id']}\">{$WbqowJxFazqBlfvnumNpfSSEYZPBSCUMHxyCE['emulator_name']} - {$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['description']} [{$_LANG['PORT']}: {$bpLJmEeeqmPlRphXHmzbyCUKbYLYitQXIXTLJ['port']}]</option>"; } echo "</select></td>"; } echo "</tr>"; } ?> </tbody>
    </table>
    <center>
      <button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button>
    </center>
  </form>
  <hr />
  </form>
  <br />
  <br /> <?php if(!$pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV) { echo "<br /><div class='alert alert-info'><p>".$_LANG['SELECT_SERVER_MASTER']."</p></div><br />"; } ?> <?php if(!empty($pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV)) { ?> <table
    style="text-align: center;" class="table table-bordered datatable"
    id="table-1"
  >
    <thead>
      <tr>
        <th scope="col"><?php echo $_LANG['DOMAIN']; ?></th>
        <th scope="col"><?php echo $_LANG['DESCRIPTION']; ?></th>
        <th scope="col"><?php echo $_LANG['EMULATOR']; ?></th>
        <th scope="col"><?php echo $_LANG['PORT']; ?></th>
        <th scope="col"><?php echo $_LANG['TOTAL_LINES']; ?></th>
        <th scope="col" style="width: 65px;"><?php echo $_LANG['MODIFY']; ?></th>
      </tr>
    </thead>
    <tbody> <?php foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc] as $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu) { ?> <tr>
        <td><?php echo $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['domain_name']; ?></td>
        <td><?php echo $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['description']; ?></td>
        <td><b><?php echo $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['emulator_name']; ?></b></td>
        <td><?php echo $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['port']; ?></td>
        <td> <?php echo LRRvJRBocmjnEzgAdfYcVBQNajQyraJvPfM($UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']); ?> </td>
        <td><a
          onclick="ajax_request_dialog('servers.php?action=edit_details&server_id=<?php echo $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']; ?>')"
          class="table-icon edit" href="#"
        ></a> <?php if($UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['can_delete'] == 1) echo "<a onclick=\"return confirm('{$_LANG['DELETE_CONFIRM']}')\" href=\"servers.php?action=delete&id={$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']}\" class=\"table-icon delete\" title=\"{$_LANG['DELETE']}\"></a>"; ?> </td>
      </tr> <?php } ?> </tbody>
  </table>
  <br />
  <br />
  <form method="post"
    action="servers.php?action=transfer&master_server_id=<?php echo $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc; ?>"
  >
    <table style="text-align: center;" class="table table-bordered">
      <thead>
        <th colspan="2"><?php echo $_LANG['TRANSFER_LINES']; ?></th>
      </thead>
      <tbody>
        <tr>
          <td><?php echo $_LANG['FROM']; ?></a></td>
          <td><select name="transfer_from">"; <?php foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc] as $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu) { echo "<option value=\"{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']}\">{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['emulator_name']} - {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['description']} [{$_LANG['PORT']}: {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['port']}]</option>"; } ?> </select>
          </td>
        </tr>
        <tr>
          <td><?php echo $_LANG['TO']; ?></a></td>
          <td><select name="transfer_to">"; <?php foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc] as $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu) { echo "<option value=\"{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']}\">{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['emulator_name']} - {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['description']} [{$_LANG['PORT']}: {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['port']}]</option>"; } ?> </select>
          </td>
        </tr>
        <tr>
          <td></td>
          <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
        </tr>
      </tbody>
      </form> <?php } ?> <form action="servers.php?action=new_server"
        method="post"
      >
        <table style="text-align: center;" class="table table-bordered">
          <thead>
            <th colspan="2"><?php echo $_LANG['CREATE_SERVER']; ?></th>
          </thead>
          <tbody>
            <tr>
              <td> <?php echo $_LANG['MASTER_SERVER']; ?> </td>
              <td><select name="master_server_id"> <?php foreach($TOalrzJJdXiIDajyLzxIJgHvcBliArw as $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw) { if($pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV AND $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id'] == $zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc) { echo "<option value=\"{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}\" selected>{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</option>"; } else { echo "<option value=\"{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}\">{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</option>"; } } ?> </select>
              </td>
            </tr>
            <tr>
              <td><?php echo $_LANG['DOMAIN']; ?></td>
              <td><input type="text" name="domain_name" value="" /></td>
            </tr>
            <tr>
              <td><?php echo $_LANG['DESCRIPTION']; ?></td>
              <td><input type="text" name="description" value="" /></td>
            </tr>
            <tr>
              <td><?php echo $_LANG['EMULATOR']; ?></td>
              <td><select name="emulator_id"> <?php foreach($ssyAoHeSjuaVqJNHUoyEMNBPhDQUldyooZIIL as $zWTaSlfAGQvEiDLlWliUczjQjFNEPOrKlQ) { if($zWTaSlfAGQvEiDLlWliUczjQjFNEPOrKlQ['can_multiple'] == 1) { echo "<option value=\"{$zWTaSlfAGQvEiDLlWliUczjQjFNEPOrKlQ['id']}\">{$zWTaSlfAGQvEiDLlWliUczjQjFNEPOrKlQ['emulator_name']}</option>"; } } ?> </select>
              </td>
            </tr>
            <tr>
              <td><?php echo $_LANG['PORT']; ?></td>
              <td><input type="text" name="port" value="" /></td>
            </tr>
            <tr>
              <td></td>
              <td><button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button></td>
            </tr>
          </tbody>
        </table>
      </form>
      </center> <?php } ?>
