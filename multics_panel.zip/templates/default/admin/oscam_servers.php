<h3>Manage Oscam Servers</h3>
<p align="center">Oscam Servers</p>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['STATUS']; ?></th>
      <th scope="col"><?php echo $_LANG['DOMAIN']; ?></th>
      <th scope="col"><?php echo $_LANG['USERNAME_FIELD']; ?></th>
      <th scope="col"><?php echo $_LANG['PASSWORD_FIELD']; ?></th>
      <th scope="col"><?php echo $_LANG['PORT']; ?></th>
      <th scope="col"><?php echo $_LANG['ENABLE_MONITOR']; ?></th>
      <th scope="col"><?php echo $_LANG['UPDATE_CONFIG']; ?></th>
      <th scope="col"><?php echo $_LANG['PREVIEW']; ?></th>
      <th scope="col" style="width: 120px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> 
<?php foreach($run as $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw) { if($XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['status'] == 1) { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/online.png' title='Online'>"; } else { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/offline.png' title='Offline'>"; } ?> <tr>
      <td><?php echo $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ; ?></td>
      <td><?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']; ?></td>
      <td><?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['username']; ?></td>
      <td><?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['password']; ?></td>
      <td><?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['port']; ?></td>
      <td><select name="monitor_enabled"
        onchange="location.href='master_servers.php?action=edit&master_server_id=<?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']; ?>&monitor=' + this.value"
      > <?php echo $VxfVMhgSqUMrHlGedbYBbEBOaFDjxujQUqCM[$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['monitor_enabled']]; foreach($VxfVMhgSqUMrHlGedbYBbEBOaFDjxujQUqCM as $uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc=>$snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM) { if($uLLgHBmPthKUFeERtjXtrvBKCOuDsRwXcfc == $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['monitor_enabled']) continue; echo $snmwuFrtGBXxOFNZAbDPBzKeqiHsBVM; } ?> </select>
      </td>
      <td><a
        onclick="ajax_request_dialog('master_servers.php?action=update_config&master_server_id=<?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']; ?>')"
        class="table-icon update" href="#"
      ></a></td>
      <td><a
        onclick="ajax_request_dialog('master_servers.php?action=preview_config&master_server_id=<?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']; ?>')"
        class="table-icon view" href="#"
      ></a></td>
      <td><a
        onclick="ajax_request_dialog('master_servers.php?action=edit_details&master_server_id=<?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']; ?>')"
        class="table-icon edit" href="#"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['READ_CONFIG_WARNING']; ?>')"
        class="table-icon config_read"
        href="master_servers.php?action=read_config&id=<?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']; ?>"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM_MASTER_SERVER']; ?>')"
        class="table-icon delete"
        href="master_servers.php?action=del_server&id=<?php echo $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
<br />
<br />
<form action="master_servers.php?action=new_server" method="post">
  <table style="text-align: center;" class="table table-bordered">
    <thead>
      <th colspan="2"><?php echo $_LANG['ADD_NEW_SERVER']; ?></th>
    </thead>
    <tbody>
      <tr>
        <td><?php echo $_LANG['DOMAIN']; ?></td>
        <td><input type="text" name="domain_name" value="" /></td>
      </tr>
      <tr>
        <td><?php echo $_LANG['PORT']; ?></td>
        <td><input type="text" name="port" value="" /></td>
      </tr>
      <tr>
        <td><?php echo $_LANG['USERNAME_FIELD']; ?></td>
        <td><input type="text" name="username" value="" /></td>
      </tr>
      <tr>
        <td><?php echo $_LANG['PASSWORD_FIELD']; ?></td>
        <td><input type="text" name="password" value="" /></td>
      </tr>
      <tr>
        <td><?php echo $_LANG['ENABLE_MONITOR']; ?></td>
        <td><input id="monitor_enabled" name="monitor_enabled"
          type="checkbox" value="1"
        /></td>
      </tr>
      <tr>
        <td><?php echo $_LANG['MASTER_SERVERS_IMPORT_AS']; ?> **</td>
        <td>Fresh <input type="radio" name="import_as" value="0" /> Keep
          Settings <input type="radio" name="import_as" value="1"
          checked
        /></td>
      </tr>
      <tr>
        <td></td>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['ADD_NEW_SERVER']; ?></button></td>
      </tr>
    </tbody>
  </table> <?php echo $_LANG['IMPORT_AS_EXPLAIN']; ?> </form>
<?php } ?>
