<h3><?php echo $_LANG['ADD_SERVER_NEW']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form action="add_server_new.php?action=new" method="post">
  <table style="text-align: center;" class="table table-bordered">
    <tbody>
      <tr>
        <td><?php echo $_LANG['NEW_TITLE']; ?></td>
        <td><input type="text" name="news_title" /></td>
      </tr>
      <tr>
        <td colspan="2"><textarea class="form-control ckeditor"
            name="news_content"
          ></textarea></td>
      </tr>
    </tbody>
  </table>
  <br />
  <center>
    <button type="submit" class="btn btn-info"><?php echo $_LANG['ADD']; ?></button>
  </center>
</form>
<?php } ?>
