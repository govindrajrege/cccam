<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['EDIT_NEWS']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post"
          action="server_news_view.php?action=save&id=<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['id']; ?>"
        >
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $_LANG['NEW_TITLE']; ?></label>
            <div class="col-sm-5">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="news_title" size="100"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['news_title']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <textarea class="form-control ckeditor" name="news_content"><?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['news_content']; ?></textarea>
          </div>
          <center>
            <button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button>
          </center>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
