<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['PACKAGE_EDIT']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post"
          action="edit_package.php?action=save&id=<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['id']; ?>"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_TYPE']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="option_type"> <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['option_type'] == 0) { echo "<option value=\"0\" selected>{$_LANG['LINE_PACKAGE_TEST']}</option>"; echo "<option value=\"1\">{$_LANG['LINE_PACKAGE_OFFICIAL']}</option>"; } else { echo "<option value=\"1\" selected>{$_LANG['LINE_PACKAGE_OFFICIAL']}</option>"; echo "<option value=\"0\">{$_LANG['LINE_PACKAGE_TEST']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_NAME']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="option_name"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['option_name']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['SUBSERVER_SELECT_PACKAGE']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="server_id">
                <option
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['server_id']; ?>"
                  selected
                ><?php echo $QGAdyPypMZilsNsRECtsZhEElyjjnXYw['emulator_name'] . "- {$QGAdyPypMZilsNsRECtsZhEElyjjnXYw['description']} [{$_LANG['PORT']}: {$QGAdyPypMZilsNsRECtsZhEElyjjnXYw['port']}]"; ?></option> <?php foreach($nqAKFozIcCWReIAlUiuMyHpiZenOuJtoFzGdlxs[$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['master_server_id']] as $UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu) { if($UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id'] == $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['server_id']) continue; echo "<option value=\"{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['id']}\">{$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['emulator_name']} - {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['description']} [{$_LANG['PORT']}: {$UhdkqnTQnEoyfBWewLEhdfWfwOVxxofwLJu['port']}]</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PROFILES']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="profiles[]" size="10"
                multiple="multiple"
              > <?php $MdFZhSrIfVzxaqeLjrhMmhjytRArNZrOM = explode(",",$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['profiles']); foreach($PUWXehduSmEptZYeeotezsmpWnQXCRgpVRPsE as $WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI) { if(in_array($WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id'],$MdFZhSrIfVzxaqeLjrhMmhjytRArNZrOM)) { echo "<option value=\"{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']}\" selected>{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['profile_name']}</option>"; } else { echo "<option value=\"{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['id']}\">{$WSVDZhEHvOJutoXJFuRlHglbEzTBWaGwZhjKI['profile_name']}</option>"; } } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PACKAGE_MONITOR_EXCLUDE']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="monitor_exclude"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['monitor_exclude'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PACKAGE_CHANGE_EMU']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="allow_ch_emu"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['allow_ch_emu'] == 1) echo 'checked'; ?>
                >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PACKAGE_SELECT_GROUPS']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="groups[]" size="5"
                multiple="multiple"
              > <?php foreach($oHBSDAuHJygtOaTtglLlZLpFieculMarhTWExQ as $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk) { if(array_key_exists($ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id'],$roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['groups'])) { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\" selected>{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } else { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\">{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_DURATION']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control" name="duration"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['duration']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_DURATION_IN']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="duration_in">
                <option value="h"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['duration_in'] == 'h') echo 'selected'; ?>
                ><?php echo $_LANG['LINE_PACKAGE_DUR_HOURS']; ?></option>
                <option value="d"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['duration_in'] == 'd') echo 'selected'; ?>
                ><?php echo $_LANG['LINE_PACKAGE_DUR_DAYS']; ?></option>
                <option value="m"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['duration_in'] == 'm') echo 'selected'; ?>
                ><?php echo $_LANG['LINE_PACKAGE_DUR_MONTHS']; ?></option>
                <option value="y"
                  <?php if($roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['duration_in'] == 'y') echo 'selected'; ?>
                ><?php echo $_LANG['LINE_PACKAGE_DUR_YEARS']; ?></option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['LINE_PACKAGE_NPRICE'] . ' - ' . mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['CURRENCY_CODE']; ?> (<font
              color="red"
            ><?php echo $_LANG['ENTER0FREE']; ?></font>)</label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="normal_price"
                  value="<?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['normal_price']; ?>"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['NOTES']; ?></label>
            <div class="col-sm-5">
              <textarea class="form-control" id="field-ta" name="info"><?php echo $roZfphrbRciTKEYMqDDHmudrSgbNGKIclfJ['info']; ?></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['PACKAGE_EDIT']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
