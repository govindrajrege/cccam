<h3><?php echo $_LANG['TICKETS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(empty($eLZWExYxwpTNueIwfWFjtEWJUrwhJQNJlIhSVyM)) { echo "<p align='center'><font color='red'>".$_LANG['NO_TICKETS_FOUND']."</font></p><br /><br />"; } else { ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['TICKET_NEW_POST']; ?></th>
      <th scope="col"><?php echo $_LANG['DATE']; ?></th>
      <th scope="col"><?php echo $_LANG['MEMBER_NAME']; ?></th>
      <th scope="col"><?php echo $_LANG['NEW_TITLE']; ?></th>
      <th scope="col"><?php echo $_LANG['VIEW']; ?></th>
      <th scope="col"><?php echo $_LANG['DELETE']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($eLZWExYxwpTNueIwfWFjtEWJUrwhJQNJlIhSVyM as $dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO) { ?> <tr>
      <td><?php echo ($dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO['admin_read'] == 1) ? "<font color='green'>{$_LANG['NO']}</font>" : "<font color='red'>{$_LANG['YES']}</font>"; ?></td>
      <td><?php echo date("F j, Y, g:i a",$dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO['date']); ?></td>
      <td><?php echo $mcMember->enuLZXwCAGrbvPofcgEYEOgeRSIcNwSMgoze($dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO['member_id']); ?></td>
      <td><?php echo $dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO['topic_title']; ?></td>
      <td><a
        href="ticketview.php?id=<?php echo $dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO['id']; ?>"
        class="table-icon view" title="<?php echo $_LANG['VIEW']; ?>"
      ></a></td>
      <td><a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        href="tickets.php?action=delete&id=<?php echo $dqKokJCnpDPBqPjIJqqCrQhidHlJQUYVXO['id']; ?>"
        class="table-icon delete" title="<?php echo $_LANG['VIEW']; ?>"
      ></a></td> <?php } ?> 
  
  </tbody>
</table>
<?php } ?>
<br />
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['NEW_TICKET_ADMIN']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post" action="tickets.php?action=new_ticket"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['MEMBER_NAME']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="member_id">
                <option value="">----</option> <?php foreach($JHurzFuNvXZKpptMwRRmyetfKPuAoDlLrGxk as $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM) { echo "<option value=\"{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']}\">{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['username']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['NEW_TITLE']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="ticket_title"
                />
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['TICKET_MESSAGE']; ?></label>
            <div class="col-sm-5">
              <textarea class="form-control" id="field-ta" rows="10"
                name="post"
              ></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
