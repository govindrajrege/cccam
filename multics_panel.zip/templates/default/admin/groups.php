<h3><?php echo $_LANG['USER_GROUPS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<p align="center"><?php echo $_LANG['MASTER_SERVERS_DESC']; ?></p>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['GROUP_NAME']; ?></th>
      <th scope="col"><?php echo $_LANG['IS_ADMIN']; ?></th>
      <th scope="col"><?php echo $_LANG['IS_BANNED']; ?></th>
      <th scope="col"><?php echo $_LANG['TOTAL_TESTLINES']; ?></th>
      <th scope="col"><?php echo $_LANG['PERCENT_DISCOUNT']; ?></th>
      <th scope="col"><?php echo $_LANG['TOTAL_USERS']; ?></th>
      <th scope="col" style="width: 120px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($oHBSDAuHJygtOaTtglLlZLpFieculMarhTWExQ as $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk) { ?> <tr>
      <td><?php echo "<font color='".$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_color']."'>{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</font>"; ?></td>
      <td><?php echo ($ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['is_admin'] == 1) ? "<font color='red'>{$_LANG['YES']}</font>" : "<font color='green'>{$_LANG['NO']}</font>"; ?></td>
      <td><?php echo ($ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['is_banned'] == 1) ? "<font color='red'>{$_LANG['YES']}</font>" : "<font color='green'>{$_LANG['NO']}</font>"; ?></td>
      <td><?php echo $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['total_testlines']; ?></td>
      <td><?php echo $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['percent_discount']; ?>%</td>
      <td><?php echo aUNCGCbXrGaWPGXUzAfbLtvzyhrKohXo($ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']); ?></td>
      <td><a
        href='edit_group.php?id=<?php echo $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']; ?>'
        class="table-icon edit"
      ></a> <?php if($ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['can_delete'] == 1) { ?> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        class="table-icon delete"
        href="groups.php?action=del&group_id=<?php echo $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']; ?>"
      ></a> <?php } ?> </td>
    </tr> <?php } ?> </tbody>
</table>
<br />
<br />
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['TRANSFER_MEMBERS']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post" action="groups.php?action=transfer"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['FROM']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="group_from"> <?php foreach($oHBSDAuHJygtOaTtglLlZLpFieculMarhTWExQ as $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk) { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\">{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['TO']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="group_to"> <?php foreach($oHBSDAuHJygtOaTtglLlZLpFieculMarhTWExQ as $ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk) { echo "<option value=\"{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['id']}\">{$ZUiCNKsHHTcZHBtzpWnycXQihtvEtvMNjnk['group_name']}</option>"; } ?> </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['DO_IT']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['ADD_NEW_GROUP']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post" action="groups.php?action=new"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['GROUP_NAME']; ?></label>
            <div class="col-sm-2">
              <input type="text" class="form-control" name="group_name" />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['GROUP_COLOR']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control colorpicker"
                  name="group_color" data-format="hex" value="#000000"
                />
                <div class="input-group-addon">
                  <i class="color-preview"></i>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['CAN_ACCESS_ADMINCP']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="is_admin">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['GROUP_IS_BANNED']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="is_banned">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['TOTAL_TESTLINES']; ?></label>
            <div class="col-sm-2">
              <input type="text" class="form-control" value="0"
                name="total_testlines"
              />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['PERCENT_DISCOUNT']; ?></label>
            <div class="col-sm-2">
              <input type="text" class="form-control"
                name="percent_discount" value="0"
              />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['ADD_NEW_GROUP']; ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
