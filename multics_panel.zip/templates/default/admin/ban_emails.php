<h3><?php echo $_LANG['PLUGIN_BAN_EMAILS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<form method="post" action="ban_emails.php?action=setting">
  <table class="table table-bordered">
    <tbody>
      <tr>
        <td><?php echo $_LANG['SETTING_ENABLE_EMAIL_BAN_LIST']; ?> </td>
        <td><input type="radio" name="ENABLE_EMAIL_BAN_LIST" value="1"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_EMAIL_BAN_LIST'] == 1) echo 'checked'; ?>
        /> Yes <input type="radio" name="ENABLE_EMAIL_BAN_LIST"
          value="0"
          <?php if (mcLib::$DCAniUabCJTZRZoqVOqPyWvFCsiwIw['ENABLE_EMAIL_BAN_LIST'] != 1) echo 'checked'; ?>
        /> No</td>
      </tr>
      <tr>
        <td></td>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button></td>
      </tr>
    </tbody>
  </table>
</form>
<form method="post" action="ban_emails.php?action=save">
  <table style="text-align: center;" class="table table-bordered">
    <thead>
      <tr>
        <th scope="col"><?php echo $_LANG['EMAILS_LIST_MANAGE']; ?></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><textarea name="ban_emails" cols="150" rows="30"><?php foreach($MwXlEsupBucfSTruoNyaGdzVggyXug as $QqgMNuniXIYAtablpoPbEPBUxcJUMNlddmRs) echo $QqgMNuniXIYAtablpoPbEPBUxcJUMNlddmRs['email'] . "\r\n"; ?></textarea></td>
      </tr>
      <tr>
        <td><button type="submit" class="btn btn-info"><?php echo $_LANG['SAVE']; ?></button></td>
      </tr>
    </tbody>
  </table>
</form>
<?php } ?>
