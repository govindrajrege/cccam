<h3><?php echo $_LANG['LINES']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(!empty($pSCkZFwsyFwNHCPJZOjjZePbrcWrCxgamgV)) { ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr> <?php if($KtnQANqUYvmmfUcMjkEICMdKLxpFgWIbfEE == 1) { echo "<th scope=\"col\">{$_LANG['ONLINE_OFFLINE']}</th>"; } ?> <th><?php echo $_LANG['STATUS']; ?></th>
      <th><?php echo $_LANG['LINE_USERNAME']; ?></th>
      <th><?php echo $_LANG['LINE_OWNER']; ?></th>
      <th><?php echo $_LANG['EMULATOR']; ?></th>
      <th><?php echo $_LANG['EXPIRE_DATE']; ?></th>
      <th><?php echo $_LANG['BLOCK_UNBLOCK']; ?></th> <?php if($KtnQANqUYvmmfUcMjkEICMdKLxpFgWIbfEE == 1) { echo "<th scope=\"col\" style=\"width: 65px;\">{$_LANG['INFO']}</th>"; } ?> <th
        scope="col" style="width: 120px;"
      ><?php echo $_LANG['PREVIEW_LINE']; ?></th>
      <th scope="col" style="width: 150px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($YCWzarlpjCjbSnAvzVqxuHSpdXhJNytYMjp as $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT) { $BFpXwGCohRpLDDAXolgFFoOBrbQrTlvNngu = NRomAbAHrJdQfOJAogpMYCugQnXcHuSyhFEps($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT); if($KtnQANqUYvmmfUcMjkEICMdKLxpFgWIbfEE == 1) { $SITJQUmAacAjxNbnQyWcGEwAkuYPZCQpZR = "info.php?multics_id=0&emu=0"; if($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['online'] == 1) { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/online.png' title='Online'>"; } elseif($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['online'] == 2) { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/idle.png' title='Idle'>"; } else { $ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ = "<img src='../templates/default/assets/images/offline.png' title='Offline'>"; } $MmaAWwcrXgnarAMErfoXchAXOOHmbPOfaOcLcE = $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['multics_id']; $lineid = $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; $on = $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['online']; $uname = $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['username']; $zWTaSlfAGQvEiDLlWliUczjQjFNEPOrKlQ = strtolower($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['emulator_name']); $SITJQUmAacAjxNbnQyWcGEwAkuYPZCQpZR = "info.php?multics_id=$MmaAWwcrXgnarAMErfoXchAXOOHmbPOfaOcLcE&emu=$zWTaSlfAGQvEiDLlWliUczjQjFNEPOrKlQ&master_server_id=$zfOHpbrRvMDuFXGWAmyEOzLchxOAEZonYsc&lineid=$lineid&online=$on&username=$uname"; } if($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['test_line'] == 1) { $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw = "<font color='red'>".$YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['username']; } else { $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw = "<font color='green'>".$YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['username']; } $nQznhInsIxzvjhlgDufkGfUdbVfcI = (!is_null($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['date_end'])) ? date("F j, Y, g:i a",$YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['date_end']) : "<font color='#ff1493'><b>".$_LANG['UNLIMITED']."</b></font>"; ?> <tr> <?php if($KtnQANqUYvmmfUcMjkEICMdKLxpFgWIbfEE == 1) { echo "<td>$ykzIStviHqaapooqEhaymnIqOkOjYkRVYOjHQ</td>"; } ?> <td><?php echo $BFpXwGCohRpLDDAXolgFFoOBrbQrTlvNngu; ?></td>
      <td><?php echo $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw; ?></td>
      <td><?php echo $mcMember->enuLZXwCAGrbvPofcgEYEOgeRSIcNwSMgoze($YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['member_id']); ?></td>
      <td><?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['emulator_name']; ?></td>
      <td><?php echo $nQznhInsIxzvjhlgDufkGfUdbVfcI; ?></td>
      <td><a
        href="mnglines.php?action=unblock&id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>"
        class="table-icon unblock"
        title="<?php echo $_LANG['UNBLOCK']; ?>"
      ></a> <a
        href="mnglines.php?action=block&id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>"
        class="table-icon block" title="<?php echo $_LANG['BLOCK']; ?>"
      ></a></td> <?php if($KtnQANqUYvmmfUcMjkEICMdKLxpFgWIbfEE == 1) { echo " <td> <a onclick=\"ajax_request_dialog('$SITJQUmAacAjxNbnQyWcGEwAkuYPZCQpZR')\" class=\"table-icon info\" href=\"#\"></a> </td>"; } ?> <td><a
        onclick="ajax_request_dialog('mnglines.php?action=show_preview&id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>')"
        href="#" class="table-icon view"
      ></a></td>
      <td><a
        href="mnglines.php?action=enable&id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>"
        class="table-icon enable"
        title="<?php echo $_LANG['ENABLE']; ?>"
      ></a> <a
        href="mnglines.php?action=disable&id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>"
        class="table-icon disable"
        title="<?php echo $_LANG['DISABLE']; ?>"
      ></a> <a
        href="editline.php?id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>"
        class="table-icon edit" title="<?php echo $_LANG['EDIT']; ?>"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        href="mnglines.php?action=delete&id=<?php echo $YcocofCYXiTPRBJexeEGlCtGuXaFDxBDMT['id']; ?>"
        class="table-icon delete"
        title="<?php echo $_LANG['DELETE']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
<?php } } ?>
