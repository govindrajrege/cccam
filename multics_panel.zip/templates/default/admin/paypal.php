<h3><?php echo $_LANG['PAYPAL']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?> <?php if(empty($rZmqGdBndqoGfDszsKECdVKCWVNiZSXwjcE)) { echo "<div class=\"alert alert-danger\">".$_LANG['NO_PAYMENT_MADE']."</div>"; } else { echo "<p align='center'>".$_LANG['DELETING_PAYMENT']."</p>"; } ?> <?php if(!empty($rZmqGdBndqoGfDszsKECdVKCWVNiZSXwjcE)) { ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col"><?php echo $_LANG['TXN_ID_CARD']; ?></th>
      <th scope="col"><?php echo $_LANG['MEMBER_NAME']; ?></th>
      <th scope="col"><?php echo $_LANG['AMOUNT']; ?></th>
      <th scope="col"><?php echo $_LANG['PAYER_EMAIL']; ?></th>
      <th scope="col"><?php echo $_LANG['DATE']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($rZmqGdBndqoGfDszsKECdVKCWVNiZSXwjcE as $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY) { ?> <tr>
      <td><?php echo $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY['card_txn']; ?></td>
      <td><?php echo $mcMember->enuLZXwCAGrbvPofcgEYEOgeRSIcNwSMgoze($VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY['member_id']); ?></td>
      <td><?php echo $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY['amount']; ?></td>
      <td><?php echo $VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY['payer_email']; ?></td>
      <td><?php echo date("F j, Y, g:i a",$VSWwcnHcApqPsyGMYMmsvLAFJOljygPOY['date']); ?></td>
    </tr> <?php } ?> </tbody>
</table>
<?php } ?> <?php } ?>
