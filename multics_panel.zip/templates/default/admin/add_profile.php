<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default panel-shadow">
      <div class="panel-heading">
        <div class="panel-title"> <?php echo $_LANG['ADD_NEW_PROFILE']; ?> </div>
        <div class="panel-options">
          <a href="#" data-rel="collapse"><i class="entypo-down-open"></i></a>
          <a href="#" data-rel="close"><i class="entypo-cancel"></i></a>
        </div>
      </div>
      <div class="panel-body">
        <form role="form" class="form-horizontal form-groups-bordered"
          method="post" action="add_profile.php?action=new"
        >
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['SELECT_MULTICS_SERVER']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="master_server_id"
                onchange="location.href='add_profile.php?master_server_id=' + this.value"
              >
                <option value="">----</option> <?php foreach($TOalrzJJdXiIDajyLzxIJgHvcBliArw as $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw) { if($NizxbPwJCLsCiHdDXcmMhqRwATbZpYDGY AND $XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id'] == $HbZUQGnrGvgDChEuqKvyDJXkzwnaEbgQE) { echo "<option value=\"{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}\" selected>{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</option>"; } else { echo "<option value=\"{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['id']}\">{$XJrWwzCuHsMWbsdvQwtGNhHQNeCdzMDw['domain']}</option>"; } } ?> </select>
            </div>
          </div> <?php if(!empty($NizxbPwJCLsCiHdDXcmMhqRwATbZpYDGY)) { ?> <div
            class="form-group"
          >
            <label class="col-sm-3 control-label"><?php echo $_LANG['PROFILE_NAME']; ?></label>
            <div class="col-sm-2">
              <div class="input-group">
                <input type="text" class="form-control"
                  name="profile_name"
                />
              </div>
            </div>
          </div> <?php if(!empty($ftIznUWGlGdmUWNSGAwhoEtPjjUAiUIs)) { ?> <div
            class="form-group"
          >
            <label class="col-sm-3 control-label"><?php echo $_LANG['INCLUDE_PROFILE_IN_PACKAGE']; ?></label>
            <div class="col-sm-3">
              <select class="form-control" name="package_ids[]" size="5"
                multiple="multiple"
              > <?php foreach($ftIznUWGlGdmUWNSGAwhoEtPjjUAiUIs as $MModueQXIxnweTxcEUFBrOXDQdRZHcdE) { echo "<option value=\"{$MModueQXIxnweTxcEUFBrOXDQdRZHcdE['id']}\">{$MModueQXIxnweTxcEUFBrOXDQdRZHcdE['option_name']}</option>"; } ?> </select>
            </div>
          </div> <?php } ?> <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['INCLUDE_PROFILE_IN_LINES']; ?></label>
            <div class="col-sm-5">
              <div class="make-switch">
                <input type="checkbox" name="include_in_lines" checked>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"><?php echo $_LANG['POST_PROFILE_OPTIONS']; ?></label>
            <div class="col-sm-5">
              <textarea class="form-control" id="field-ta" rows="10"
                name="profile_options"
              > ############################## [Example Profile Name] ############################## PORT : 12003 CAID: 0664 PROVIDERS: 000000, 000001, 000002, 000003 ONID: 7e </textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label"></label>
            <div class="col-sm-2">
              <button type="submit" class="btn btn-info"><?php echo $_LANG['ADD_NEW_PROFILE']; ?></button>
            </div>
          </div> <?php } ?> </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
