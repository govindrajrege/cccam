<h3><?php echo $_LANG['REGISTERED_USERS']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th><?php echo $_LANG['USERNAME_FIELD']; ?></th>
      <th><?php echo $_LANG['GROUP_NAME']; ?></th>
      <th><?php echo $_LANG['EMAIL_FIELD']; ?></th>
      <th><?php echo $_LANG['IP']; ?></th>
      <th><?php echo $_LANG['REG_DATE']; ?></th>
      <th><?php echo $_LANG['AC_BALANCE']; ?></th>
      <th><?php echo $_LANG['TOTAL_PURCHASED_LINES']; ?></th>
      <th><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($JHurzFuNvXZKpptMwRRmyetfKPuAoDlLrGxk as $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM) { if($rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['verified'] == 1) { $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw = "<font color=\"green\">{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['username']}</font>"; } else { $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw = "<font color=\"red\">{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['username']}</font>"; } ?> <tr>
      <td><a
        onclick="ajax_request_dialog('regusers.php?action=show_lines&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']; ?>')"
        href="#"
      ><?php echo $DhgeTYztpZKYLMRRlOkmQbtyEwRLDkOPGBLGw; ?></a></td>
      <td><?php echo "<font color='".$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['group_color']."'>{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['group_name']}</font>"; ?></td>
      <td><?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['email']; ?></td>
      <td> <?php if(function_exists('geoip_country_code_by_name')) { $EacFoBTLyChXdxQTTzlPiqUlkZLOTYaqFM = strtolower(geoip_country_code_by_name($rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['ip'])); $iWHlFTenieDgzqGCEBCbMeVSVnzjWanWo = "<img src='../templates/default/img/flags/unknown.png' title='unknown'>"; if(@$EacFoBTLyChXdxQTTzlPiqUlkZLOTYaqFM) { $iWHlFTenieDgzqGCEBCbMeVSVnzjWanWo = "<img src='../templates/default/img/flags/".$EacFoBTLyChXdxQTTzlPiqUlkZLOTYaqFM.".png' title='".$EacFoBTLyChXdxQTTzlPiqUlkZLOTYaqFM."'>"; } echo "<div align='left'>".$iWHlFTenieDgzqGCEBCbMeVSVnzjWanWo." <a target=\"blank\" href=\"http://www.ip-adress.com/ip_tracer/{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['ip']}\">" . $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['ip'] . "</a></div>"; } else { echo "<a target=\"blank\" href=\"http://www.ip-adress.com/ip_tracer/{$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['ip']}\">" . $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['ip'] . "</a>"; } ?> </td>
      <td><?php echo date("F j, Y, g:i a",$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['date_registered']); ?></td>
      <td><?php echo ($rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['balance'] > 0) ? '<b>'.$rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['balance'].'</b>' : $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['balance']; ?></td>
      <td><?php echo bZWXkyKAYCPkgQLmXSIeBWVWOuYeLNcZdhbY($rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']); ?></td>
      <td><a
        onclick="ajax_request_dialog('regusers.php?action=send_email&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']; ?>')"
        href="#" class="table-icon email"
        title="<?php echo $_LANG['SEND_EMAIL_USER']; ?>"
      ></a> <a
        href="edituser.php?id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']; ?>"
        class="table-icon edit" title="<?php echo $_LANG['EDIT']; ?>"
      ></a> <a
        onclick="return confirm('<?php echo $_LANG['DELETE_CONFIRM']; ?>')"
        href="regusers.php?action=delete&id=<?php echo $rKtjjytgRkFCZvsYCbiuXywNLejYVPlhNM['id']; ?>"
        class="table-icon delete"
        title="<?php echo $_LANG['DELETE']; ?>"
      ></a></td>
    </tr> <?php } ?> </tbody>
</table>
<?php } ?>
