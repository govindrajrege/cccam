<h3><?php echo $_LANG['TASK_MANAGER']; ?></h3>
<?php if(!empty($yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('error',$yLLOktibmLFNwZObcCrTwUXtobuvMjVbGkeVxf); else { if(!empty($aRKoHdPwsRcopaMNzctndtspFWJHoWs)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('warning',$aRKoHdPwsRcopaMNzctndtspFWJHoWs); if(!empty($iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM)) echo qpvldMTAVaiMrhLqJToqUWOsYiwmAxdWesagA('ok',$iqfNPvkOqtFXpbNtWgKFCZulSjUVbTGrxnBM); ?>
<table style="text-align: center;"
  class="table table-bordered datatable" id="table-1"
>
  <thead>
    <tr>
      <th scope="col" style="width: 150px;"><?php echo $_LANG['STATUS']; ?></th>
      <th scope="col"><?php echo $_LANG['DESCRIPTION']; ?></th>
      <th scope="col" style="width: 150px;"><?php echo $_LANG['MODIFY']; ?></th>
    </tr>
  </thead>
  <tbody> <?php foreach($YJohdVrrNFArexBoAFczyrDNgUgUqfOlWFOvs as $ZttOQsMcNSiqFIOCfzEcbBejXFezo) { $BFpXwGCohRpLDDAXolgFFoOBrbQrTlvNngu = ($ZttOQsMcNSiqFIOCfzEcbBejXFezo['enabled'] == 1) ? "<font color=\"green\">{$_LANG['RUNNING']}</font>" : "<font color=\"orange\">{$_LANG['DISABLED']}</font>"; ?> <form
      method="post"
      action="task_manager.php?action=save&id=<?php echo $ZttOQsMcNSiqFIOCfzEcbBejXFezo['id']; ?>"
    >
      <tr>
        <td><?php echo $BFpXwGCohRpLDDAXolgFFoOBrbQrTlvNngu; ?></td>
        <td><?php echo $ZttOQsMcNSiqFIOCfzEcbBejXFezo['description']; ?></td>
        <td><a
          href="task_manager.php?action=enable&id=<?php echo $ZttOQsMcNSiqFIOCfzEcbBejXFezo['id']; ?>"
          class="table-icon enable"
          title="<?php echo $_LANG['ENABLE']; ?>"
        ></a> <a
          href="task_manager.php?action=disable&id=<?php echo $ZttOQsMcNSiqFIOCfzEcbBejXFezo['id']; ?>"
          class="table-icon disable"
          title="<?php echo $_LANG['DISABLE']; ?>"
        ></a></td>
      </tr>
    </form> <?php } ?> </tbody>
</table>
<?php } ?>
