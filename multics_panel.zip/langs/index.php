<?php

function checkemail($email)
{
	global $rizwan;
	$array = array('email' => $email);
	$sel = $rizwan->select('lines', $array);
	$num = $rizwan->num_rows($sel);
	return $num;
}

function checkip($ip)
{
	global $rizwan;
	$array = array('ip' => $ip);
	$sel = $rizwan->select('lines', $array);
	$num = $rizwan->num_rows($sel);
	return $num;
}

function addline($name, $email, $ip, $luser, $lpass, $ldate)
{
	global $rizwan;
	$array = array('username' => $luser, 'password' => $lpass, 'name' => $name, 'email' => $email, 'ip' => $ip, 'end_date' => $ldate);
	$ins = $rizwan->insert('lines', $array);
	return $ins;
}